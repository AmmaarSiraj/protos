<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MAKINASIK</title>
    <link rel="icon" type="image/png" href="../../public/uploads/system/cmB0dOEcGv3EpOhtwixU5w94hqCCjPosh7Rvmm9J.png" />
    @viteReactRefresh
    
    @vite('src/main.jsx')
</head>
<body>
    <div id="root"></div>
</body>
</html>