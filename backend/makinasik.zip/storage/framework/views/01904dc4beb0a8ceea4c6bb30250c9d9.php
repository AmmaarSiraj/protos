<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MAKINASIK</title>
    <link rel="icon" type="image/png" href="/logo.png" />
    <?php echo app('Illuminate\Foundation\Vite')->reactRefresh(); ?>
    
    <?php echo app('Illuminate\Foundation\Vite')('src/main.jsx'); ?>
</head>
<body>
    <div id="root"></div>
</body>
</html><?php /**PATH D:\kuliah\semester 7\1. project akhir\backend\resources\views\welcome.blade.php ENDPATH**/ ?>